typedef struct tcb{
	float execTime;
	void (*fun)();//This is a function pointer
}tcb;
